const contractAddress = "0x95d5ae4681226ae99C07A941d4904419dAe5fA13";
const contractABI = [/* your contract ABI here */];

let provider;
let signer;
let contract;

async function connectWallet() {
  if (typeof window.ethereum === "undefined") {
    alert("Please install MetaMask.");
    return;
  }

  try {
    await window.ethereum.request({ method: "eth_requestAccounts" });
    provider = new ethers.providers.Web3Provider(window.ethereum);
    signer = provider.getSigner();
    contract = new ethers.Contract(contractAddress, contractABI, signer);
    alert("Wallet connected!");
  } catch (err) {
    console.error(err);
    alert("Failed to connect wallet.");
  }
}

async function mintTokens() {
  if (!contract) return alert("Please connect your wallet first.");
  try {
    const amount = ethers.utils.parseUnits("1", 18); // 1 token
    const tx = await contract.mint(await signer.getAddress(), amount);
    await tx.wait();
    alert("Successfully minted 1 TTKN token!");
  } catch (err) {
    console.error(err);
    alert("Mint failed.");
  }
}
